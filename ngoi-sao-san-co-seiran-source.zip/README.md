# Ngôi Sao Sân Cỏ Seiran — Web/App

Trang đọc truyện "Ngôi Sao Sân Cỏ Seiran" (HTML/CSS/JS thuần), đóng gói sẵn dưới dạng Electron app cho macOS.

## Chạy thử ở chế độ web
Chỉ cần mở trực tiếp file `index.html` bằng trình duyệt.

## Build thành app macOS
```bash
npm install
npm run build:mac
```
File `.app` sẽ nằm trong `dist/mac` (Intel) hoặc `dist/mac-arm64` (Apple Silicon).

## Chạy ở chế độ dev (Electron)
```bash
npm install
npm start
```
